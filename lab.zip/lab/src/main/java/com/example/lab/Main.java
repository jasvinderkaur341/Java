package com.example.lab;

import com.google.gson.Gson;
import java.io.IOException;

public class Main {

    public static void main(String[] args) {
        try {
            String apiKey = "AIzaSyD9hV8Vt1E6HQxrHnIubK7QYF2b8AEWUrU"; // Replace with your actual API key
            String jsonResponse = APIUtility.callAPIWithKey("https://www.googleapis.com/books/v1/volumes?q=java", apiKey);

            Gson gson = new Gson();
            Book[] books = gson.fromJson(jsonResponse, Book[].class);

            for (Book book : books) {
                System.out.println("Title: " + book.getTitle());
                System.out.println("Author: " + book.getAuthor());
                System.out.println("---------------------");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
