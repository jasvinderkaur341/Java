module com.example.assignment_2nd {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.google.gson;
    requires okhttp3;

    opens com.example.assignment_2nd to javafx.fxml;
    exports com.example.assignment_2nd;
    exports com.example.assignment_2nd.controller;
    opens com.example.assignment_2nd.controller to javafx.fxml;
}